PROJECT:
Linda Bushel — Pool Deck

ISSUE:
J1

STATUS:
Preliminary Construction and Supplier Pricing Basis
Subject to Permit Review and Field Verification

ADDRESS:
12 D'Arcy's Way, Kemptville, ON K0G 1J0

FOUNDATION:
15 helical piers. Not sonotubes. No concrete.
Shaft, helix, length, torque, and capacity are not specified.

IMPORTANT:
- supplier pricing has NOT yet been received
- customer selling price has NOT been issued
- internal direct cost is not yet finalized
- drawing remains preliminary
- field verification and permit/municipal requirements remain

CONTENTS:
DRAWINGS/   current J1 11x17 preliminary set
TAKEOFF/    quantities reconciled to that drawing
ESTIMATE/   internal cost sheet for Ben only
SUPPLIER/   request for quotation for Darcy at BMR Winchester; not a quotation received
CUSTOMER/   preliminary customer draft; not ready to issue a price

The estimate sheet is marked INTERNAL / FOR BEN.
The customer draft is marked PRELIMINARY / BUDGET ESTIMATE and SELLING PRICE NOT ISSUED.
Do not send the customer draft as a priced estimate.
