CalibraytAI refined review edition, 18 October 2026.
44 pages, 14 chapters. Approved brand artwork remains embedded unchanged.
Run refine_book.py then package_book.py to regenerate the reading and deployment editions. Pillow and fontTools are authoring dependencies; no runtime dependencies.
The original live Vercel project is prj_dC5qstDwfnbZLcD1EdNeK9l97n63, account team_VBgdZDEQi72xBacwVcFjMvkQ.
This edition was NOT published: Vercel returned 403 forbidden for the connected account scope.
17 focused code/asset checks passed; changed SVG pages visually inspected; no real-browser walkthrough of this new edition was possible.
Render helper uses @resvg/resvg-js; adjust its require path to your installed package.
