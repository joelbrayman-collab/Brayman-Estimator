"""Bounded editorial overlays. Original approved page/brand bytes remain embedded.
All screen details are crops of the supplied synthetic capture package.
"""
from pathlib import Path
import base64, json, re, html, shutil, hashlib
from PIL import ImageFont, Image

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'release'; OUT.mkdir(exist_ok=True)
FONT=ROOT/'fonts/IBM-Plex-0.ttf'
GOLD='#9e7c24'; INK='#263331'
def uri(p):
    p=Path(p); mime={'.jpg':'image/jpeg','.png':'image/png','.svg':'image/svg+xml'}[p.suffix]
    return 'data:'+mime+';base64,'+base64.b64encode(p.read_bytes()).decode()
def screen(name): return next((ROOT/'screenshots').rglob(name))
fonturi='data:font/ttf;base64,'+base64.b64encode(FONT.read_bytes()).decode()
class Page:
    def __init__(self,n):
        self.n=n; self.parts=[f'<image href="{uri(ROOT/f"original-pages/{n:02}.jpg")}" width="1275" height="1650"/>'];self.masks=[]
    def clear(self,x,y,w,h,color='white'):
        if x==130: w=1075
        self.parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{color}"/>');self.masks.append([x,y,w,h])
    def para(self,text,x,y,w,size=24,line=36,fill=INK,weight=400):
        font=ImageFont.truetype(str(FONT),size);lines=[];s=''
        for word in text.split():
            test=(s+' '+word).strip()
            if font.getlength(test)>w and s:lines.append(s);s=word
            else:s=test
        if s:lines.append(s)
        self.parts.append(f'<text x="{x}" y="{y}" font-family="IBM Plex Sans" font-size="{size}" font-weight="{weight}" fill="{fill}">'+''.join(f'<tspan x="{x}" dy="{0 if i==0 else line}">{html.escape(t)}</tspan>' for i,t in enumerate(lines))+'</text>')
        return y+line*len(lines)
    def image(self,p,x,y,w,h,crop=None):
        iw,ih=Image.open(p).size
        if crop:
            cx,cy,cw,ch=crop
            self.parts.append(f'<svg x="{x}" y="{y}" width="{w}" height="{h}" viewBox="{cx} {cy} {cw} {ch}" preserveAspectRatio="xMidYMid meet"><image href="{uri(p)}" width="{iw}" height="{ih}"/></svg>')
        else:self.parts.append(f'<image href="{uri(p)}" x="{x}" y="{y}" width="{w}" height="{h}" preserveAspectRatio="xMidYMid meet"/>')
    def save(self):
        s='<svg xmlns="http://www.w3.org/2000/svg" width="1275" height="1650" viewBox="0 0 1275 1650"><style>@font-face{font-family:"IBM Plex Sans";src:url('+fonturi+')}</style>'+''.join(self.parts)+'</svg>'
        (OUT/f'page-{self.n:02}.svg').write_text(s)
        return self.masks

changes={}; details={}
def done(p):changes[str(p.n)]=p.save()
def detail(n,p,label,crop=None):
    target=f'detail-{n:02}{p.suffix}';shutil.copyfile(p,OUT/target)
    details[str(n)]={'src':target,'label':label,'crop':crop}

p=Page(3);p.clear(130,775,1030,110)
p.para('Follow one contractor and one project, from the first customer call to the final walkthrough.',135,810,1000,size=28,line=41)
done(p)

p=Page(13);p.clear(130,245,1020,340)
y=p.para('The customer and project records bring the address, scope and pricing assumptions together. Harbour Lane starts with Morgan Ellis, a pool-deck idea and one place to keep the job.',135,280,1000)
y=p.para('The recorded location stays with the project and its contract information. Every drawing, estimate, schedule and change order then belongs to that same job.',135,y+16,1000)
p.para('When Morgan calls again, the contractor can return to the project history, including the estimates, proposals and signed documents, without reconstructing the agreement from old emails.',135,y+16,1000)
done(p)

p=Page(19);p.clear(130,200,1020,405)
y=p.para('Enter the measured dimensions and CalibraytAI calculates the quantities. Its tools cover concrete, footings, stairs, ICF walls, framing, roofing, siding, drywall and flooring.',135,235,1000)
y=p.para('The stair example below turns the entered rise and run into a labelled diagram. The result shows the riser and tread counts, their dimensions and checks against the named profile.',135,y+16,1000)
p.para('Use the tools for a quick answer on site, and keep the calculation with the work it supports. The diagram makes the result easier to understand and discuss.',135,y+16,1000)
p.clear(130,595,1020,625)
sp=screen('12-stairs-and-diagram-desktop-1440.png')
p.image(sp,135,610,1000,505,(530,1840,2280,1360))
p.para('ACTUAL STAIR CALCULATOR · DIAGRAM DETAIL',135,1155,1000,size=19,line=26,fill=GOLD)
p.para('Six risers and five treads, with the dimensions shown on the drawing.',135,1190,1000,size=21,line=30)
done(p);detail(19,sp,'Stair calculator: entered dimensions, diagram and profile checks')

p=Page(23)
# Retain the approved serif headline pixels; remove the unsupported final phrase.
p.clear(745,120,460,65)
p.parts.append('<circle cx="748" cy="153" r="2.2" fill="#162120"/>')
p.clear(130,205,1020,440)
y=p.para('CalibraytAI prepares a supplier request with material lines, quantities and specifications. The supplier can return SKUs, unit prices and discounts on the pricing form, giving both sides a clear record of what is being quoted.',135,245,1000)
y=p.para('The returned prices are recorded in the supplier-response screen. CalibraytAI calculates line totals and keeps provisional items and substitutions visible for review. The contractor decides which supplier receives the request and which costs are approved.',135,y+18,1000)
p.para('The same organized handoff works with the yard the contractor chooses. Direct system-to-system supplier connections are described in The road ahead.',135,y+18,1000)
done(p);detail(23,screen('20-supplier-price-entry-desktop-1440.png'),'Supplier response: quantities, unit prices and line totals')

p=Page(27);p.clear(130,640,1020,590)
p.image(screen('24-estimate-totals-desktop-1440.png'),135,650,1000,297)
p.para('THE ESTIMATE TOTALS',135,990,1000,size=20,line=28,fill=GOLD)
p.para('Direct costs, pre-tax selling price, tax and the customer total are shown together. Open the detail view to inspect the original customer estimate.',135,1030,1000,size=24,line=36)
done(p);detail(27,ROOT/'26-customer-estimate.pdf.png','Original Harbour Lane customer estimate — generated PDF')

p=Page(29);p.clear(130,200,1020,340)
y=p.para('The accepted estimate becomes the starting point for the contract. The project record retains the contract package, version and job information together.',135,235,1000)
y=p.para('The customer opens the signing link, reviews the agreement, gives consent and signs on a phone or computer. The contractor countersigns, and the executed document and signing record stay with the job.',135,y+18,1000)
p.para('The connection matters: the agreement, the accepted figures and the project history can be reviewed together when a question arises.',135,y+18,1000)
done(p);detail(29,screen('28-signer-signed-mobile-390.png'),'Customer signing screen after signature')

p=Page(31);p.clear(130,640,1020,610)
sp=screen('31-project-work-plan-desktop-1440.png')
# Show the real schedule, rather than claiming an empty calendar demonstrates assigned work.
p.image(sp,135,655,1000,265,(0,0,2320,615))
p.image(sp,135,940,1000,210,(0,1840,2320,490))
p.para('PROJECT WORK · SCHEDULE DETAIL',135,1155,1000,size=19,line=28,fill=GOLD)
p.para('The project work screen links the work items to their dates and assignment fields.',135,1195,1000,size=22,line=32)
done(p);detail(31,sp,'Project work: labour, schedule dates and assignment fields')

p=Page(37);p.clear(130,200,1020,345)
y=p.para('Return to Harbour Lane at the end of the journey. The original estimate, approved change and actual costs are still attached to the same project.',135,235,1000)
y=p.para('The Money view puts estimated and actual figures together. It gives the contractor a place to review how the job performed, rather than relying on a memory of whether it went well.',135,y+18,1000)
p.para('That retained record is the foundation for the next estimating decision: what was allowed, what changed and what the work actually cost.',135,y+18,1000)
p.clear(130,555,1020,650)
sp=screen('32-estimated-versus-actual-desktop-1440.png')
p.image(sp,135,575,1000,540,(0,0,2320,1620))
p.para('MONEY · ESTIMATED VERSUS ACTUAL',135,1165,1000,size=20,line=28,fill=GOLD)
done(p);detail(37,sp,'Money: estimated versus actual, from the synthetic project record')

p=Page(39);p.clear(130,250,1020,130,'#081426')
p.para('The project record is the foundation. These are the next connections being developed around it.',135,285,1000,size=31,line=45,fill='#e4e5e3')
done(p)

p=Page(40);p.clear(95,220,1110,145)
p.para('Harbour Lane began with Morgan’s idea. The drawing, material list, estimate, agreement and work history now belong to one retained project record.',100,252,1030,size=25,line=37)
p.clear(95,1190,1055,300)
for y,t in [(1230,'PLAN + PRICE  ·  Confirmed scope, drawing and estimate.'),(1290,'CONTRACT + BUILD  ·  Agreement, work plan and recorded change.'),(1350,'MONITOR + LEARN  ·  Actual costs and a retained project history.')]:p.para(t,100,y,1030,size=25,line=36)
done(p)

p=Page(41);p.clear(130,425,1020,280,'#081426')
p.para('Walk through Harbour Lane with us. See how a customer idea becomes a drawing, an estimate, an agreement and a project record you can return to.',135,460,1000,size=30,line=44,fill='#c1c5ca')
p.para('ARRANGE A WALKTHROUGH',135,635,1000,size=25,line=34,fill='#c9ae70')
p.para('Use the contact button in the reader to get in touch with Joel.',135,680,1000,size=23,line=32,fill='#c1c5ca')
done(p)

for n in range(1,45):
    if str(n) not in changes:shutil.copyfile(ROOT/f'original-pages/{n:02}.jpg',OUT/f'page-{n:02}.jpg')
manifest={'edition':'Refined review · 18 October 2026','pages':44,'chapters':14,'changes':changes,'details':details,'unchanged_brand_pages':[1,2,43,44],'original_page_sha256':{str(n):hashlib.sha256((ROOT/f'original-pages/{n:02}.jpg').read_bytes()).hexdigest() for n in range(1,45)}}
(ROOT/'editorial-manifest.json').write_text(json.dumps(manifest,indent=2))
(OUT/'page-data.json').write_text(json.dumps({'pages':[f'page-{n:02}.'+('svg' if str(n) in changes else 'jpg') for n in range(1,45)],'details':details},indent=2))
print('Preserved 44 pages; editorial overlays:',','.join(changes))
