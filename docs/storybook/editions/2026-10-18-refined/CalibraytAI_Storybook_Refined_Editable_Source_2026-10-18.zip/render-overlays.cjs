const {Resvg}=require('../airia-book-update/render-tools/node_modules/@resvg/resvg-js');
const fs=require('fs'),path=require('path'); const root=__dirname;
for(const file of fs.readdirSync(path.join(root,'release')).filter(f=>f.endsWith('.svg'))){
const png=new Resvg(fs.readFileSync(path.join(root,'release',file)),{font:{fontFiles:[path.join(root,'fonts/IBM-Plex-0.ttf')],loadSystemFonts:true}}).render().asPng();
fs.mkdirSync(path.join(root,'rendered'),{recursive:true});fs.writeFileSync(path.join(root,'rendered',file.replace('.svg','.png')),png);
}
